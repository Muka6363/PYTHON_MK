def selam(name) :
    print("hello", name)